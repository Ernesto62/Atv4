ID:{{$autores->id_autor}}<br>
Nome:{{$autores->nome}}<br>
Nacionalidade:{{$autores->nacionalidade}}